<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="google-site-verification" content="NZMV7sopzbGBXYz9bEDWKttF-FT61oaY2F_oxFbQvzU" />
  <title>Tupay79 :: Situs Game Online Deposit & Withdraw DANA Tanpa Potongan!</title>
  <meta name="page google.com" content="https://www.google.com/search?q=TUPAY79">
  <meta name="page google.co.id" content="https://www.google.co.id/search?q=TUPAY79">
  <meta name="description" content="Main game online dan dapatkan uang asli di Tupay79. Dengan deposit & WD via DANA, prosesnya lebih cepat dan tanpa potongan!">
  <meta name="keywords" content="Tupay79">
  <meta name="robots" content="index, follow"> 
  <meta name="author" content="Tupay79">
  <meta name="publisher" content="Tupay79"/>
  <meta name="categories" content="website">
  <meta name="geo.placename" content="Indonesia"/>
  <meta name="geo.country" content="ID"/>
  <meta name="language" content="id-ID"/>
  <meta name="tgn.nation" content="Indonesia"/>
  <meta name="distribution" content="global"/>
  <meta name="apple-mobile-web-app-capable" content="yes"/>
  <meta name="mobile-web-app-capable" content="yes"/>
  <link rel="canonical" href="https://perpus.pn-kutacane.go.id/registration/">
  <link rel="amphtml" href="https://revolusioner-rjp01.com/perpus.cane/tupay79/">

 <!-- Bootstarp CSS -->
  <style>
    body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background:#d4af37;  
    }

    .container {
    display: flex;
    max-width: 1200px;
    margin: 20px auto;
    background: white;
    padding: 20px;
    gap: 40px;
    border-radius: 20px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); /* Added box-shadow */
    }


    .product-images {
    flex: 1;
    }

    .main-img {
    width: 100%;
    border-radius: 10px;
    }

    .thumbnail-group {
    display: flex;
    gap: 10px;
    margin-top: 15px;
    }

    .thumbnail-group img {
    width: 60px;
    height: 80px;
    object-fit: cover;
    border-radius: 5px;
    cursor: pointer;
    border: 1px solid #ccc;
    }

    .product-details {
    flex: 1;
    }

    .tag {
    background: #eee;
    color: #333;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    text-align: center;
    }

    h1 {
    margin-top: 10px;
    font-size: 28px;
    }

    .rating {
    margin: 10px 0;
    color: #093028;
    }

    .price {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 24px;
    margin: 10px 0;
    }

    .price .old {
    text-decoration: line-through;
    color: gray;
    font-size: 18px;
    }

    .options label {
    display: block;
    margin-top: 20px;
    font-weight: bold;
    }

    .color-options {
    display: flex;
    gap: 10px;
    margin-top: 10px;
    }

    .color {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 1px solid #ccc;
    cursor: pointer;
    }

    .color1 {
    background-color: #f4f0e9;
    }

    .color2 {
    background-color: #fff000;
    }

    .quantity {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 10px;
    }

    .quantity button {
    width: 30px;
    height: 30px;
    font-size: 18px;
    border-radius: 20px;
    }

    /* Smooth transitions for all buttons */
    button {
    transition: all 0.3s ease;
    }

    /* Hover effect for size buttons */
    .sizes button:hover {
    background-color: #f0f0f0;
    border-color: #089000;
    transform: scale(1.05);
    }

    /* Hover effect for BUY IT NOW button */
    .actions .buy:hover {
    background-color: #333;
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    }

    /* Hover effect for ADD TO CART button */
    .actions .add-cart:hover {
    background-color: #f7f7f7;
    transform: translateY(-2px);
    border-color: #333;
    }

    /* Hover effect for quantity buttons */
    .quantity button:hover {
    background-color: #eee;
    transform: scale(1.1);
    }

    .quantity input {
    width: 40px;
    text-align: center;
    }

    .sizes {
    display: flex;
    gap: 10px;
    margin-top: 10px;
    }

    .sizes button {
    padding: 8px 14px;
    border: 1px solid #ccc;
    background: none;
    cursor: pointer;
    }

    .actions {
    margin-top: 30px;
    display: flex;
    gap: 15px;
    
    }

    .actions .buy,
    .actions .add-cart {
    padding: 12px 20px;
    font-size: 16px;
    text-align: center;
    border: none;
    cursor: pointer;
    border-radius: 6px;
    text-decoration: none;
    color: #000;
    width: 50%;
    }

    .actions .buy {
    background-color: #d4af37;
    color: white;
    width: 50%;
    text-align: center;
    }

    .actions .add-cart {
    background: white;
    border: 1px solid #089000;
    width: 50%;
    text-align: center;
    }

    .meta {
    margin-top: 20px;
    font-size: 14px;
    color: #666;
    }

    .socials {
    margin-top: 10px;
    display: flex;
    gap: 10px;
    font-size: 20px;
    }

    .socials a {
    color: inherit; 
    text-decoration: none;
    }


    /* Navbar */
    .navbar {
    background: #fff;
    border-bottom: 1px solid #eee;
    padding: 15px 30px;
    font-family: 'Arial', sans-serif;
    }

    .navbar-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    }

    .logo {
    display: flex;
    align-items: center;
    height: 100px;
    width: 250px;
    background-color: #000;
    padding: 20px;
    border-radius: 10px;
    }

    .logo img {
    height: 100%;
    width: 100%;
    object-fit: contain;
    }


    .nav-links {
    list-style: none;
    display: flex;
    gap: 30px;
    margin: 0;
    padding: 0;
    }

    .nav-links a {
    text-decoration: none;
    color: #444;
    font-weight: 500;
    font-size: 20px;
    }

    .nav-links a:hover {
    color: #007bff; 
    text-decoration: underline; 
    }

    .nav-links a.active {
    font-weight: bold;
    color: #000;
    }

    .nav-icons {
    display: flex;
    align-items: center;
    gap: 20px;
    }

    .nav-icons i {
    font-size: 20px;
    color: #333;
    cursor: pointer;
    }

    .cart-btn {
    background-color: #f4f4f4;
    border: none;
    padding: 8px 15px;
    border-radius: 30px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    }

    .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    }

    /* product details */
    .extra-details {
    margin-top: 30px;
    font-size: 0.95rem;
    line-height: 1.6;
    color: #444;
    }

    .extra-details a {
        color: #fff000;
        font-weight: bold;
        text-decoration: none;
    }

    a:hover {
        color:#d4af37;
    }

    .extra-details h1, h2, h3, h4 {
        text-align: center;
    }

    .extra-details h2 {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 10px;
    }

    .extra-details ul {
    padding-left: 20px;
    list-style-type: disc;
    }

    .extra-details li {
    margin-bottom: 6px;
    }

    /* hamburger menu */
    /* Hamburger button */
    .hamburger {
    background: none;
    border: none;
    font-size: 1.4rem;
    display: none;
    cursor: pointer;
    color: #333;
    }


    /* mobile view */
    @media (max-width: 768px) {
    .container {
        flex-direction: column;
        padding: 15px;
        gap: 20px;
    }

    .product-details {
        display: flex;
        flex-direction: column;
    }

    .hamburger {
        display: block;
    }

    .nav-links {
        display: none;
        flex-direction: column;
        width: 100%;
        background: #fff;
        position: absolute;
        top: 70px;
        left: 0;
        padding: 10px 20px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        z-index: 999;
    }

    .nav-links.show {
        display: flex;
    }

    .nav-links li {
        width: 100%;
    }

    .nav-links a {
        display: block;
        width: 100%;
        padding: 10px 0;
        font-size: 1rem;
        border-bottom: 1px solid #eee;
    }

    .navbar-container {
        position: relative;
        flex-wrap: wrap;
    }

    .nav-icons {
        display: none;
    }

    .product-details h1 {
        font-size: 22px;
    }

    .price {
        flex-direction: column;
        align-items: flex-start;
    }

    .sizes {
        flex-wrap: wrap;
    }

    .actions {
        order: -1; 
        margin-top: 0;
        margin-bottom: 15px; 
        gap: 10px;
    }

    .actions .buy,
    .actions .add-cart {
        width: 80%;
    }

    .thumbnail-group {
        justify-content: center;
        flex-wrap: wrap;
    }

    .extra-details h2 {
        font-size: 1rem;
    }

    .extra-details {
        font-size: 0.9rem;
    }

    .logo {
        height: 50px;
    }

    .logo img {
        height: auto;
        max-height: 50px;
    }
    }

    @media (max-width: 480px) {
    .container {
        flex-direction: column;
        padding: 15px;
        gap: 20px;
    }

    .product-details {
        display: flex;
        flex-direction: column;
    }

    .hamburger {
        display: block;
    }

    .nav-links {
        display: none;
        flex-direction: column;
        width: 100%;
        background: #fff;
        position: absolute;
        top: 70px;
        left: 0;
        padding: 10px 20px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        z-index: 999;
    }

    .nav-links.show {
        display: flex;
    }

    .nav-links li {
        width: 100%;
    }

    .nav-links a {
        display: block;
        width: 100%;
        padding: 10px 0;
        font-size: 1rem;
        border-bottom: 1px solid #eee;
    }

    .navbar-container {
        position: relative;
        flex-wrap: wrap;
    }

    .nav-icons {
        display: none;
    }

    .product-details h1 {
        font-size: 22px;
    }

    .price {
        flex-direction: column;
        align-items: flex-start;
    }

    .sizes {
        flex-wrap: wrap;
    }

    .actions {
        order: -1; 
        margin-top: 0;
        margin-bottom: 15px; 
        gap: 10px;
    }

    .actions .buy,
    .actions .add-cart {
        width: 80%;
    }

    .thumbnail-group {
        justify-content: center;
        flex-wrap: wrap;
    }

    .extra-details h2 {
        font-size: 1rem;
    }

    .extra-details {
        font-size: 0.9rem;
    }

    .logo {
        height: 50px;
    }

    .logo img {
        height: auto;
        max-height: 50px;
    }
    }

    .footer {
    background: black;
    color: white;
    padding: 40px 0 20px;
    font-family: 'Poppins', sans-serif;
    }

    .footer-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    }

    .footer-section h3 {
    font-size: 18px;
    margin-bottom: 20px;
    position: relative;
    padding-bottom: 10px;
    }

    .footer-section h3::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 50px;
    height: 2px;
    background: #fdbb2d;
    }

    .footer-section ul {
    list-style: none;
    padding: 0;
    }

    .footer-section ul li {
    margin-bottom: 10px;
    }

    .footer-section ul li a {
    color: #ddd;
    text-decoration: none;
    transition: color 0.3s;
    }

    .footer-section ul li a:hover {
    color: #fdbb2d;
    }

    .payment-methods {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    }

    .payment-methods img {
    height: 80px;
    background: white;
    padding: 5px;
    border-radius: 6px;
    }

    .contact-info {
    display: flex;
    flex-direction: column;
    gap: 12px;
    }

    .contact-item {
    display: flex;
    align-items: center;
    gap: 10px;
    color: inherit;
    text-decoration: none;
    padding: 8px 12px;
    border-radius: 6px;
    transition: all 0.3s ease;
    }

    .contact-item:hover {
    background: rgba(0, 0, 0, 0.05);
    transform: translateX(5px);
    }

    .contact-item i {
    font-size: 18px;
    width: 20px;
    text-align: center;
    }

    .contact-item[href^="mailto"] i { color: #ffffff; }
    .contact-item[href*="whatsapp"] i { color: #fff000; }
    .contact-item[href*="chat"] i { color: #00e0f9; }

    .social-links {
    display: flex;
    gap: 15px;
    }

    .social-links a {
    color: white;
    font-size: 20px;
    transition: color 0.3s;
    }

    .social-links a:hover {
    color: #fdbb2d;
    }

    .copyright-section {
    text-align: center;
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.1);
    }

    .copyright-section a {
        color: #fff000;
        font-weight: bold;
        text-decoration: line-through;
    }

    a:hover {
        color: #d4af37;
    }

    .legal-links {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin: 15px 0;
    }

    .legal-links a {
    color: #ddd;
    text-decoration: none;
    }

    .disclaimer {
    font-size: 12px;
    opacity: 0.8;
    margin-top: 20px;
    }

    @media (max-width: 768px) {
    .footer-container {
        grid-template-columns: 1fr 1fr;
    }
    }

    @media (max-width: 480px) {
    .footer-container {
        grid-template-columns: 1fr;
    }
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Open Graph for Social Media -->
   <link rel="preload" href="https://galeri-revolusi.com/sandz/tupay79.webp" as="image" />
  <meta property="og:title" content="Tupay79 :: Situs Game Online Deposit & Withdraw DANA Tanpa Potongan!">
  <meta property="og:description" content="Main game online dan dapatkan uang asli di Tupay79. Dengan deposit & WD via DANA, prosesnya lebih cepat dan tanpa potongan!">
  <meta property="og:image" content="https://galeri-revolusi.com/sandz/tupay79.webp">
  <meta property="og:url" content="https://perpus.pn-kutacane.go.id/registration/">
  <meta property="og:type" content="website">

  <!-- Favicon -->
  <link rel="icon" href="https://galeri-revolusi.com/logo/tupay79.png" type="image/png" />

    <!-- Schema.org JSON-LD -->
    <script type="application/ld+json">
      {
        "@context": "http://schema.org",
        "@type": "Product",
        "name": "Tupay79",
        "image": "https://galeri-revolusi.com/sandz/tupay79.webp",
        "description": "Main game online dan dapatkan uang asli di Tupay79. Dengan deposit & WD via DANA, prosesnya lebih cepat dan tanpa potongan!",
        "sku": "GHFT92545AAA",
        "offers": {
          "@type": "Offer",
          "url": "https://cutt.ly/erWXk5JB",
          "priceCurrency": "IDR",
          "price": "20000",
          "priceValidUntil": "2025-12-31",
          "itemCondition": "http://schema.org/NewCondition",
          "availability": "http://schema.org/InStock",
          "seller": {
            "@type": "Organization",
            "name": "Tupay79"
          }
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.8",
          "reviewCount": "350"
        }
      }
    </script>

    <script type="application/ld+json">
    {
    "@context": "https://schema.org/",
    "@type": "WebSite",
    "name": "TUPAY79",
    "url": "https://perpus.pn-kutacane.go.id/registration/",
    "potentialAction": {
        "@type": "SearchAction",
        "target": "https://www.google.co.id/{search_term_string}TUPAY79",
        "query-input": "required name=search_term_string"
    }
    }
    </script>

</head>

<body>

<!-- Navbar -->
<nav class="navbar">
    <div class="navbar-container">
      <div class="logo">
        <a href="#">
        <img src="https://galeri-revolusi.com/logo/tupay79.png" title="Logo Tupay79" alt="logo-tupay79">
        </a>
      </div>
  
      <!-- Hamburger Icon -->
      <button class="hamburger" id="hamburger-btn">
        <i class="fa-solid fa-bars"></i>
      </button>
  
      <ul class="nav-links" id="nav-links">
        <li><a href="https://perpus.pn-kutacane.go.id/registration/">Home</a></li>
        <li><a href="https://perpus.pn-kutacane.go.id/registration/" class="active">Shop</a></li>
        <li><a href="https://perpus.pn-kutacane.go.id/registration/">About</a></li>
        <li><a href="https://perpus.pn-kutacane.go.id/registration/">Contact</a></li>
      </ul>
  
      <div class="nav-icons">
        <i class="fa-solid fa-magnifying-glass"></i>
        <i class="fa-regular fa-bell"></i>
        <button class="cart-btn">
          <i class="fa-solid fa-cart-shopping"></i> MY CART
        </button>
      </div>
    </div>
  </nav>

  <!-- hamburger script -->

  <script>
    const hamburger = document.getElementById('hamburger-btn');
    const navLinks = document.getElementById('nav-links');
  
    hamburger.addEventListener('click', () => {
      navLinks.classList.toggle('show');
    });
  </script>
  
  

  <div class="container">
    <div class="product-images">
      <a href="#">
      <img src="https://galeri-revolusi.com/sandz/tupay79.webp" alt="Tupay79" title="Banner Tupay79" class="main-img">
      </a>
    </div>

    <div class="product-details">
      <span class="tag">New</span>
      <h1>Tupay79</h1>
      <div class="rating">⭐⭐⭐⭐⭐ <span>(4.8 from 350 Reviews)</span></div>

      <div class="price">
        <span class="current">IDR 10.000</span>
        <span class="old">IDR 20.000</span>
      </div>

      <div class="options">
        <label>Available Color</label>
        <div class="color-options">
          <span class="color color1"></span>
          <span class="color color2"></span>
        </div>

        <label>Quantity</label>
        <div class="quantity">
          <button>-</button>
          <input type="text" value="1">
          <button>+</button>
        </div>

        <label>Available Size</label>
        <div class="sizes">
          <button>XS</button>
          <button>S</button>
          <button>M</button>
          <button>L</button>
          <button>XL</button>
          <button>XXL</button>
        </div>
      </div>

      <div class="actions">
        <a class="buy" href="https://cutt.ly/erWXk5JB">LOGIN</a>
        <a class="add-cart" href="https://rtp.tupay79a.online/">LINK RTP</a>
      </div>

      <div class="meta">
        <p><strong>SKU:</strong> GHFT92545AAA</p>
        <p><strong>Tags:</strong> Men, Coat, Fashion, Jacket</p>

        <div class="socials">
          <span><a href="https://perpus.pn-kutacane.go.id/registration/"><i class="fa-brands fa-telegram"></i></a></span>
          <span><a href="https://perpus.pn-kutacane.go.id/registration/"><i class="fa-brands fa-whatsapp"></i></a></span>
          <span><a href="https://perpus.pn-kutacane.go.id/registration/"><i class="fa-solid fa-headset"></i></a></span>
        </div>
      </div>

      <div class="extra-details">
        <h1>Tupay79 :: Situs Game Online Penghasil Uang Asli, Cairkan via DANA!
        </h1>
        <p><a href="#">Apakah Anda mencari platform game online yang tidak hanya seru dimainkan tetapi juga bisa menghasilkan uang asli? <a href="#">Tupay79</a> adalah solusinya! Situs ini menawarkan berbagai jenis game online dengan sistem pembayaran langsung ke DANA, sehingga memudahkan Anda dalam menikmati hasil kemenangan.</p>
        <h2>Keunggulan Tupay79</h2>
        <ul style="list-style: none;">
            <li><strong>✅ Game Online Penghasil Uang Asli</strong> – Bermain sambil dapat penghasilan tambahan.</li>
            <li><strong>✅ Withdraw via DANA</strong> – Proses pencairan cepat dan mudah.</li>
            <li><strong>✅ Aman & Terpercaya</strong> – Sistem fair play tanpa bot.</li>
            <li><strong>✅ Beragam Jenis Game</strong> – Mulai dari arcade, strategi, hingga e-sports.</li>
        </ul>
        <h3>Cara Mendapatkan Uang di Tupay79</h3>
        <ol>
            <li><strong>Daftar Akun</strong> – Buat akun gratis di situs resmi Tupay79.</li>
            <li><strong>Mainkan Game</strong> – Pilih game favorit dan raih kemenangan.</li>
            <li><strong>Kumpulkan Poin</strong> – Konversi poin menjadi saldo.</li>
            <li><strong>Withdraw via DANA</strong> – Cairkan uang langsung ke dompet digital Anda.</li>
        </ol>
        <h3>Mengapa Pilih Tupay79?</h3>
        <ul>
            <li>Proses Pencairan Cepat (Hanya 5-10 menit).</li>
            <li>Minimal Withdraw Rendah (Mulai dari Rp10.000).</li>
            <li>Bonus & Promo Menarik untuk member baru dan loyal.</li>
        </ul>
        <h4>Tunggu Apa Lagi? Daftar Sekarang di Tupay79 dan Mulai Hasilkan Uang dari Game Online!</h4>
        <p>Dengan sistem yang transparan dan dukungan transaksi via DANA, <strong>Tupay79</strong> menjadi pilihan terbaik bagi gamers yang ingin monetisasi hobi mereka. Mainkan game, menang, dan cairkan uangnya sekarang juga!</p>
        </div>
    </div>
  </div>

<footer class="footer">
  <div class="footer-container">
      
    <div class="footer-section">
      <h3>Tentang Tupay79</h3>
      <ul>
        <li><a href="https://perpus.pn-kutacane.go.id/registration/" title="Login Tupay79" alt="Beranda Tupay79">Beranda</a></li>
        <li><a href="https://cutt.ly/erWXk5JB" target="_blank" rel="nofollow noreferrer noopener" title="Login Tupay79" alt="Promo Tupay79">Promo Terbaru</a></li>
        <li><a href="https://cutt.ly/erWXk5JB" target="_blank" rel="nofollow noreferrer noopener" title="Login Tupay79" alt="Daftar Tupay79">Pendaftaran</a></li>
        <li><a href="https://cutt.ly/erWXk5JB" target="_blank" rel="nofollow noreferrer noopener" title="Login Tupay79" alt="Masuk Tupay79">Masuk Akun</a></li>
      </ul>
    </div>


    <div class="footer-section">
      <h3>Pembayaran</h3>
      <div class="payment-methods">
        <img src="https://galeri-revolusi.com/ext/logo-bank.webp" title="Login Tupay79" alt="Bank BCA, Bank BNI, Bank BRI, Bank Mandiri, E-wallet QRIS, E-wallet Gopay, E-wallet Dana, E-wallet Ovo, E-wallet Jenius" loading="lazy">
      </div>
    </div>

    <div class="footer-section">
      <h3>Follow Kami</h3>
      <div class="social-links">
        <a href="https://telegram.com/" aria-label="Telegram Tupay79"><i class="fab fa-telegram"></i></a>
        <a href="https://www.whatsapp.com/"  aria-label="WhatsApp Tupay79"><i class="fab fa-whatsapp"></i></a>
        <a href="https://www.instagram.com/"  aria-label="Instagram Tupay79"><i class="fab fa-instagram"></i></a>
      </div>
    </div>
  </div>


  <div class="copyright-section">
    <p>&copy; 2025 Tupay79<br>Powered by Revolusi SEO | <a href="#">0xSandz</a></p>
    
  </div>
</footer>

</body>
</html>
