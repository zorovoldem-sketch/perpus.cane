<?php 
header("Location: /index.php", true, 301);
exit();
?>